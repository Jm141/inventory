<?php
session_start();
include('logic/dbCon.php');

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['productName']) && isset($_POST['quantity'])) {
        $productName = $_POST['productName'];
        $quantity = $_POST['quantity'];

        if (isset($_SESSION['cart'][$productName])) {
            $_SESSION['cart'][$productName] += $quantity;
        } else {
            $_SESSION['cart'][$productName] = $quantity;
        }
    }
}
if (isset($_POST['checkout'])) {
    foreach ($_SESSION['cart'] as $product => $quantity) {
        $sql_last_code = "SELECT code FROM history ORDER BY code DESC LIMIT 1";
        $result_last_code = mysqli_query($conn, $sql_last_code);
        
        if ($result_last_code) {
            if (mysqli_num_rows($result_last_code) > 0) {
                $row = mysqli_fetch_assoc($result_last_code);
                $last_code = $row['code'];
                $Ucode = $last_code + 1;
            } else {
                $Ucode = 2023001;
            }
            $timestamp = date("Y-m-d H:i:s");
            $sql_insert = "INSERT INTO history (code, product_name, quantity, timestamp) VALUES ('$Ucode', '$product', '$quantity', '$timestamp')";
            mysqli_query($conn, $sql_insert);

            $sql_update = "UPDATE products SET quantity = quantity - $quantity WHERE product = '$product'";
            mysqli_query($conn, $sql_update);
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
    $_SESSION['cart'] = array();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS</title>
    <style>
        
    </style>
</head>
<body>

<nav>
    <ul>
        <li><a href="Inventory.php">Inventory</a></li>
        <li><a href="#">Report</a></li>
        <li><a href="POS.php">POS</a></li>
        <li><a href="StaffDashboard.php">Home</a></li>
        <li>
            <form action=" logic/logout_script.php" method="post">
                <button type="submit">Log-Out</button>
            </form>
        </li>
    </ul>
</nav>
<div class="container">
    <h2>Point of Sale</h2>
    <div id="productInput">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" name="productName" required>
            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" min="1" value="1" required>
            <button type="submit">Add to Cart</button>
        </form>
    </div>
    <div id="cart">
        <h3>Cart</h3>
        <ul id="cart-items">
            <?php
            $totalPrice = 0;
            foreach ($_SESSION['cart'] as $product => $quantity) {
                $sql_price = "SELECT price FROM products WHERE product = '$product'";
                $result_price = mysqli_query($conn, $sql_price);

                if ($result_price) {
                    $row = mysqli_fetch_assoc($result_price);
                    if ($row) {
                        $price = $row['price'];
                        $totalItemPrice = $price * $quantity;
                        echo "<li>$product - Quantity: $quantity - Total Price: $totalItemPrice</li>";
                        $totalPrice += $totalItemPrice;
                    } else {
                        echo "Error: No data retrieved from the query.";
                    }
                } else {
                    echo "Error: " . mysqli_error($conn);
                }
            }
            ?>
        </ul>
        <div id="total">Total: ₱<?php echo number_format($totalPrice, 2); ?></div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" name="checkout" value="1">
            <button type="submit">Checkout</button>
        </form>
    </div>
</div>
</body>
</html>
