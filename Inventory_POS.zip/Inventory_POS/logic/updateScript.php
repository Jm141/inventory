<?php
session_start();
include('dbCon.php');

function logActivity($conn, $userId, $activity, $timestamp) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $activity = mysqli_real_escape_string($conn, $activity);
    $timestamp = mysqli_real_escape_string($conn, $timestamp);

    $username = $_SESSION['name'];
    $sql = "INSERT INTO activity_log (userCode, activity, timestamp) VALUES ('$userId', '$username $activity', '$timestamp')";

    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $updated_fname = mysqli_real_escape_string($conn, $_POST["fname"]);
    $updated_lname = mysqli_real_escape_string($conn, $_POST["lname"]);
    $updated_email = mysqli_real_escape_string($conn, $_POST["email"]);
    $updated_username = mysqli_real_escape_string($conn, $_POST["username"]);
    $updated_password = mysqli_real_escape_string($conn, $_POST["password"]);
    $timestamp = date('Y-m-d H:i:s');

    $update_sql = "UPDATE user SET fname = '$updated_fname', lname = '$updated_lname', email = '$updated_email', username= '$updated_username', password = '$updated_password', timestamp='$timestamp' WHERE code = $user_id";

    if (mysqli_query($conn, $update_sql)) {
        $delete_sql = "DELETE FROM user_access WHERE code = $user_id";
        mysqli_query($conn, $delete_sql);

       
        if (isset($_POST['link']) && is_array($_POST['link'])) {
            foreach ($_POST['link'] as $access) {
                $insert_sql = "INSERT INTO user_access (code, access) VALUES ($user_id, '$access')";
                mysqli_query($conn, $insert_sql);
            }
        }

       
        $activity = "updated user info: $updated_fname";
        if (logActivity($conn, $user_id, $activity, $timestamp)) {
            header("Location: ../Masterdashboard.php?id=$user_id&success=true");
            exit();
        } else {
            header("Location: update.php?id=$user_id&error=true");
            exit();
        }
    } else {
        header("Location: update.php?id=$user_id&error=true");
        exit();
    }
} else {
    header("Location: ../dashboard.php");
    exit();
}
?>
