<?php
session_start();
include('dbCon.php');

function logActivity($conn, $userId, $activity) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $activity = mysqli_real_escape_string($conn, $activity);
    $username = $_SESSION['name'];
    $timestamp = date('Y-m-d H:i:s');
    $sql = "INSERT INTO activity_log (userCode, activity, timestamp) VALUES ('$userId', '$username $activity', '$timestamp')";

    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        error_log("Error in logActivity: " . mysqli_error($conn));
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $updated_Pcategory = mysqli_real_escape_string($conn, $_POST["category"]);
    $updated_Pname = mysqli_real_escape_string($conn, $_POST["product"]);
    $updated_Pprice = mysqli_real_escape_string($conn, $_POST["price"]);
    $updated_Pquantity = mysqli_real_escape_string($conn, $_POST["quantity"]);
    $timestamp = date('Y-m-d H:i:s');

    
    $update_sql = "UPDATE products SET category = '$updated_Pcategory', product = '$updated_Pname', price = '$updated_Pprice', quantity = '$updated_Pquantity', timestamp = '$timestamp' WHERE code = '$user_id'";

  
    error_log("Executing query: $update_sql");

  
    if (mysqli_query($conn, $update_sql)) {
        
        if (mysqli_affected_rows($conn) > 0) {
            $activity = "updated product info: $updated_Pname";
            if (!logActivity($conn, $user_id, $activity)) {
                error_log("Failed to log activity");
            }

            header("Location: ../Inventory.php?id=$user_id&success=true");
        } else {
            error_log("No rows were updated.");
            header("Location: ../updateProduct.php?id=$user_id&error=no_changes");
        }
        exit();
    } else {
      
        error_log("Error updating product: " . mysqli_error($conn));
        header("Location: ../updateProduct.php?id=$user_id&error=true");
        exit();
    }
} else {
    header("Location: ../Inventory.php");
    exit();
}
?>