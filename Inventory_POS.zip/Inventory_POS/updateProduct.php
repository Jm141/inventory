<?php
session_start();

include('Logic/dbCon.php');

if (!isset($_GET['code']) || empty($_GET['code'])) {
    header("Location: dashboard.php");
    exit();
}

$user_id = $_GET['code'];

$sql = "SELECT * FROM products WHERE code = $user_id";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "Product not found.";
    exit();
}

$product = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
   
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        .container {
            width: 80%;
            margin: 20px auto;
        }
        form {
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        form label {
            display: block;
            margin-bottom: 5px;
        }
        form input[type="text"],
        form input[type="number"],
        form select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        form input[type="submit"] {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
<body>

    <h1>Update Product</h1>

    <p>Welcome, <?php echo $_SESSION['name']; ?>!</p>
    <p>Email: <?php echo $_SESSION['email']; ?></p>
    <nav>
        <ul>
            <li><a href="Inventory.php">Inventory</a></li>
            <li><a href="history.php">Report</a></li>
            <li><a href="POS.php">POS</a></li>
            <li><a href="StaffDashboard.php">Home</a></li>
            <li>
             <form action=" logic/logout_script.php" method="post">
                <button type="submit">Log-Out</button>
            </form>
        </li>
        </ul>
    </nav>
    <?php
    if (isset($_GET['success']) && $_GET['success'] === 'true') {
        echo "<p style='color: green;'>User information updated successfully.</p>";
    } elseif (isset($_GET['error']) && $_GET['error'] === 'true') {
        echo "<p style='color: red;'>Error updating user information. Please try again.</p>";
    }
    ?>

    <div class="container">
    <form action="logic/updateProductScript.php" method="post">
        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
        <label for="Category">Category:</label>
        <input type="text" id="Category" name="category" value="<?php echo $product['category']; ?>" required><br><br>
		<label for="product">Product Name:</label>
        <input type="text" id="product" name="product" value="<?php echo $product['product']; ?>" required><br><br>
        <label for="price">Price:</label>
        <input type="number" id="price" name="price" value="<?php echo $product['price']; ?>" required><br><br>
        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" value="<?php echo $product['quantity']; ?>" required><br><br>     
             <input type="submit" value="Update" id="btn">
    </form>
    </div>
</body>
</html>

